<?php

require('../fpdf/fpdf.php');
require "conexao.php";


$id_tipo = $_POST['id_tipo'];
$id_departamentos = $_POST['id_departamentos'];
$assunto = $_POST['assunto'];
$anexo = $_POST['anexo'];
$vocativo = $_POST['vocativo'];
$mensagem = $_POST['mensagem'];
$desfecho = $_POST['desfecho'];
$assinatura = $_POST['assinatura'];


$most="SELECT sigla FROM tipos WHERE id_tipo = '$id_tipo'";

$resultado=pg_query($most) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de I
nform�tica.");

$row= pg_fetch_row($resultado,$i);


$most1="SELECT nomedepartamento FROM departamentos WHERE id_departamentos = '$id_departamentos'";

$resultado1=pg_query($most1) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de
 I
nform�tica.");

$row1= pg_fetch_row($resultado1,$i);



$most2="SELECT * FROM assinaturas WHERE id_assinaturas = '$assinatura'";

$resultado2=pg_query($most2) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de
 I
nform�tica.");

$row2= pg_fetch_row($resultado2,$i);





class PDF extends FPDF
{
//Cabe�alho
function Header()
{
$this->SetXY(23,28);
$this->SetFont('Times', 'B', 14);
$this->Cell(65, 0, 'Funda��o Universidade de Bras�lia');
$this->Ln(4);
$this->SetX(23);
$this->SetFont('Times', 'B', 8);
$this->Cell(65, 0, 'Departamento de Matem�tica - IE');
$this->Ln(4);
$this->SetX(23);
$this->SetLineWidth(0.5);
$this->Line($this->GetX()+1, $this->GetY()-1, $this->GetX()+168, $this->GetY()-1);
$this->Ln(2);
$this->SetX(23);
$this->SetFont('Times', '', 8);
$this->Write(0,'Campus Universit�rio, 70910-900 - Bras�lia - DF');
$tam=$this->GetStringWidth('Fone: (061) 273-3356 - FAX: (061) 274-3910');
$this->SetX(168- $tam);

$this->Write(0,'                             Fone: (061) 273-3356 - FAX: (061) 274-3910');
$this->Ln(14);

}
}


$pdf =new PDF();
$pdf->SetLeftMargin(23);
$pdf->SetRightMargin(18);
$pdf->SetTopMargin(28);
$pdf->SetAutoPageBreak('T',40);


$pdf->AddPage();



$pdf->SetLeftMargin(33);
$pdf->Ln(10);
$pdf->SetFont('Times', 'B', 12);
$pdf->Write(5, $row[0]);
$pdf->Write(5,'    ');
//$pdf->GetStringWidth('$row[0]');
$pdf->Write(5, '/MAT/N�   ');
$pdf->SetFont('Times', '', 12);
$pdf->Write(5, 'XX ');
$data = strftime("%d/%m/%Y"); 
$pdf->Cell(30,5,'/2005 ' );
$pdf->Cell(20,5,'');
$pdf->Write(5,'                          DATA: ');
$pdf->Write(5,$data);
$pdf->Ln(10);
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX()+1, $pdf->GetY()-1, $pdf->GetX()+158, $pdf->GetY()-1);
$pdf->Ln(3);
$pdf->SetFont('Times','B','12');
$pdf->Cell(0,0,'1 - IDENTIFICA��O');
$pdf->Ln(7);
$pdf->SetLeftMargin(37);
$pdf->Write(0,'Proced�ncia: ');
$pdf->SetFont('Times','','12');
$pdf->Write(0, 'DEPARTAMENTO DE MATEM�TICA');
$pdf->Ln(3);
$pdf->SetFont('Times','B','12');
$pdf->Write(5,'Destino        : ');
$pdf->SetFont('Times','','12');
$pdf->Write(5,$row1[0]);
//$pdf->Ln(8);
$pdf->SetLeftMargin(33);
$pdf->Ln(10);
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX()+1, $pdf->GetY()-1, $pdf->GetX()+158, $pdf->GetY()-1);
$pdf->Ln(3);
$pdf->SetFont('Times','B','12');
$pdf->Cell(0,0,'2 - ASSUNTO');
$pdf->Ln(7);
$pdf->SetLeftMargin(37);
$pdf->SetFont('Times','','12');
$pdf->Write(0,$assunto);

//anexo

$pdf->SetLeftMargin(33);
$pdf->Ln(8);
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX()+1, $pdf->GetY()-1, $pdf->GetX()+158, $pdf->GetY()-1);
$pdf->Ln(3);
$pdf->SetFont('Times','B','12');
$pdf->Cell(0,0,'3 - ANEXO(S)');
$pdf->Ln(7);
$pdf->SetLeftMargin(37);
$pdf->SetFont('Times','','12');
$pdf->Write(0,$anexo);

$pdf->SetLeftMargin(33);
$pdf->Ln(8);
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX()+1, $pdf->GetY()-1, $pdf->GetX()+158, $pdf->GetY()-1);
$pdf->Ln(3);
$pdf->SetFont('Times','B','12');
$pdf->Cell(0,0,'4 - MENSAGEM');
$pdf->Ln(20);
$pdf->SetLeftMargin(37);
$pdf->SetFont('Times','','12');
$pdf->Cell(13,0,'');
$pdf->Write(5,$vocativo);
$pdf->Write(5,',');
$pdf->Ln(11);
$pdf->MultiCell(0,5, $mensagem, 'J');

//desfecho

$pdf->Ln(7);
$pdf->Cell(81,0,'');
$pdf->Write(5,$desfecho);
$pdf->Write(5,',');
$pdf->Ln(20);

//assinatura

$pdf->SetLineWidth(0.5);
$tam=($pdf->GetStringWidth($row2[1]));
$pdf->Line($pdf->GetX()+81 - 0.71 * ($tam) , $pdf->GetY(), $pdf->GetX()+81 + 1.71 * ($tam) , $pdf->GetY());
$pdf->Ln(3);
$pdf->Cell(81,0,'');
$pdf->Write(5,$row2[1]);
$pdf->Ln(5);
$pdf->Cell(81,0,'');
$pdf->Write(5,$row2[2]);


 
$pdf->Output("visualizacao.pdf","I");


?>
