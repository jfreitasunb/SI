<?php

require "conexao.php";
require "verifica.php";

if ($acao2 == "Definitivo")
	{
	$sel="SELECT * FROM documentador WHERE id_tipo='$id_tipo'";

	$resultado=pg_query($sel) or die ("N\xe3o foi poss\xedvel realizar a consulta ao banco de dados");

	$contador=pg_num_rows($resultado) + 1;
	
	
	$ins1="INSERT INTO documentador (id_documentador,id_tipo,numerodocumento,id_departamentos,vocativo,mensagem,desfecho,id_assinaturas,assunto,anexo,data) VALUES (default,'$id_tipo','$contador','$id_departamentos','$vocativo','$mensagem','$desfecho','$assinatura','$assunto','$anexo','$data')";

	$resultado1=pg_query($ins1) or die("N\xe3o foi poss\xedvel inserir os dados no banco 1");

        $busc="SELECT id_documentador FROM documentador WHERE numerodocumento = '$contador' and id_tipo = '$id_tipo'";

        $resultado2=pg_query($busc) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de Inform�tica.");

        $coluna = pg_fetch_row($resultado2,$i);
        $id_documentador = $coluna[0];


        echo "
<head>
<meta http-equiv='content-type' content='text/html; charset=iso-8859-1'>

<title>Servidor Administrativo</title><style type='text/css' media='all'>@import 'style.css';</style></head>



<body>

<div id='Header'></div>

<div id='Content'>
        <h1>Servidor Administrativo</h1>
<p> O documento foi inserido com sucesso. Para que ele possa ser impresso na tela em formato <b><i>.pdf</i></b>, clique no bot�o abaixo. </p>

  <br>
<form method='post' action='t2.php'>
  <div align='center'>
    <input name='id_documentador' type='hidden' value='$id_documentador'>
    <input type='submit' name='Submit' value='PDF'>

</div>

<div id='Menu'>
        <a href='exercicio_insere.php'>Preencher Formul�rio</a><br>
        <a href='exercicio_edita_lista.php'>Buscar Documentos</a><br>
        <a href='sair.php'>Sair</a><br>

</div>
</body></html> ";


        

	pg_close($conn);

	//header("Location: operacao_ok.php");
	//exit;






	}

else
  {

        //$sel="SELECT * FROM rascunho";

        //$resultado=pg_query($sel) or die ("N\xe3o foi poss\xedvel realizar a consulta ao banco de dados");

        //$contador=pg_num_rows($resultado) + 1;


        $ins1="INSERT INTO rascunho (id_documentador,id_tipo,id_departamentos,vocativo,mensagem,desfecho,
id_assinaturas,assunto,anexo,data) VALUES (default,'$id_tipo','$id_departamentos','$vocativo','$mensagem','$desfe
cho','$assinatura','$assunto','$anexo','$data')";

        $resultado1=pg_query($ins1) or die("N\xe3o foi poss\xedvel inserir os dados no banco 1");

        //$busc="SELECT id_documentador FROM documentador WHERE numerodocumento = '$contador' and id_tipo = '$id_tipo'";

        //$resultado2=pg_query($busc) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de Inform�tica.");

        //$coluna = pg_fetch_row($resultado2,$i);
        //$id_documentador = $coluna[0];


        echo "
<head>
<meta http-equiv='content-type' content='text/html; charset=iso-8859-1'>

<title>Servidor Administrativo</title><style type='text/css' media='all'>@import 'style.css';</style></head>



<body>

<div id='Header'></div>

<div id='Content'>
        <h1>Servidor Administrativo</h1>
<p> O documento foi inserido como <i>rascunho</i>. Para que ele possa ser impresso na tela em formato <b><i>.pdf</i></b>, clique no bo
t�o abaixo. </p>

  <br>
<form method='post' action='t2_mod.php'>
  <div align='center'>
    <input name='id_tipo' type='hidden' value='$id_tipo'>
    <input name='id_departamentos' type='hidden' value='$id_departamentos'>
    <input name='assunto' type='hidden' value='$assunto'>
    <input name='anexo' type='hidden' value='$anexo'>
    <input name='vocativo' type='hidden' value='$vocativo'>
    <input name='mensagem' type='hidden' value='$mensagem'>
    <input name='desfecho' type='hidden' value='$desfecho'>
    <input name='assinatura' type='hidden' value='$assinatura'>
    <input name='data' type='hidden' value='$data'>
    <input type='submit' name='Submit' value='PDF'>

</div>

<div id='Menu'>
        <a href='exercicio_insere.php'>Preencher Formul�rio</a><br>
        <a href='exercicio_edita_lista.php'>Buscar Documentos</a><br>
        <a href='sair.php'>Sair</a><br>

</div>
</body></html> ";




        pg_close($conn);

        //header("Location: operacao_ok.php");
        //exit;
}

?>
