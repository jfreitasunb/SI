<?php
require "verifica.php";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<title>Servidor Administrativo</title><style type="text/css" media="all">@import "style.css";</style></head>

<body>
<div id="Header"></div>

<div id="Content">
        <h1>Buscar Documento</h1>
<p> Os seguintes documentos foram encontrados. Para visualizar em formato <i>.pdf</i> o documento completo, clique no link referente.</p>
<br>


<?php

require "conexao.php";

//busca pelos documentos a partir do "tipo" especificado.
$sel="SELECT id_documentador,numerodocumento,id_departamentos,vocativo,mensagem,desfecho,id_assinaturas  
      FROM documentador  
      WHERE id_tipo='$id_tipo' 
      ORDER BY id_documentador DESC";
$resultado=pg_query($sel) or die ("N�o foi poss�vel realizar a consulta ao banco de dados");
$contador=pg_num_rows($resultado);

//mostrar na tela o resultado.
if ($contador == 0)
	echo " <p> N�o existe nenhum documento.</p>";
else {
		while ($linha=pg_fetch_array($resultado))
			{
			$id_documentador=trim($linha["id_documentador"]);
			$numerodocumento=trim($linha["numerodocumento"]);
			$id_departamentos=trim($linha["id_departamentos"]);
			$mensagem=trim($linha["mensagem"]);
			$id_assinaturas=trim($linha["id_assinaturas"]);
				


$most1="SELECT nomedepartamento FROM departamentos WHERE id_departamentos = '$id_departamentos'";
$resultado1=pg_query($most1) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de
 I
nform�tica.");

$row1= pg_fetch_row($resultado1,$i);



$most2="SELECT nome FROM assinaturas WHERE id_assinaturas = '$id_assinaturas'";
$resultado2=pg_query($most2) or die("N�o foi poss�vel executar a opera��o. Contacte a Coordena��o de
 I
nform�tica.");
$row2= pg_fetch_row($resultado2,$i);



                        
 
	
			echo "<a href='operacaopdf.php?id_documentador=$id_documentador'> <p>- Destino: <b> $row1[0]</b><br> - N�mero do documento :<b> $numerodocumento</b><br>- Mensagem : <b> $mensagem</b><br>- Assinatura : <b> $row2[0]</b></a></p></font><br><br>";
		}
	}
pg_close($conn);
?>

<div id="Menu">
	<a><i>Menu</i> Documentos</a><br>
        <a href="exercicio_insere.php">Gerar</a><br>
        <a href="exercicio_edita.php">Editar</a><br>
        <a href="exercicio_edita_lista.php">Buscar</a><br>
        <a href="sair.php">Sair</a><br>

</div>
</body></head></html>
