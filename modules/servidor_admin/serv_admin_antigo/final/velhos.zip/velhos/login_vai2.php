<?php

require "conexao.php";

session_start();


$login = isset($_POST["login"]) ? addslashes(trim($_POST["login"])) : FALSE;

$senha = isset($_POST["senha"]) ? addslashes(trim($_POST["senha"])) : FALSE;

// Usu�rio n�o forneceu a senha ou o login
if(!$login || !$senha)
{
    echo "
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<title>Servidor Administrativo</title><style type="text/css" media="all">@import "style.css";</style></head>

<body>

<div id="Header"></div>

<div id="Content">
        <h1>Autentica��o Inv�lida</h1>
	<p> Voc� deve digitar sua senha e login! </p>
        <p><a href="login1.html" title="Layouts to make your own...">&lt; Retornar</a>
	</p>
</div>
</body></html>";
    exit;
}

$SQL = "SELECT nome,senha 
        FROM usuarios
        WHERE login = '$login'";
$result_id = pg_query($SQL) or die("Erro no banco de dados!");
$total = pg_num_rows($result_id);

// Caso o usu�rio tenha digitado um login v�lido o n�mero de linhas ser� 1..
if($total)
{
    // Obt�m os dados do usu�rio, para poder verificar a senha e passar os demais dados para a sess�o
    $dados = pg_fetch_array($result_id);

    // Agora verifica a senha
    if(!strcmp($senha, $dados["senha"]))
    {
        // TUDO OK! Agora, passa os dados para a sess�o e redireciona o usu�rio
        $_SESSION["nome_usuario"] = stripslashes($dados["login"]);
        header("Location: index.html");
        exit;
    }
    // Senha inv�lida
    else
    {
        echo "

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>Servidor Administrativo</title><style type="text/css" media="all">@import "style.css";</style></head>

<body>

<div id="Header"></div>

<div id="Content">
        <h1>Autentica��o Inv�lida</h1>
        <p> A senha fornecida � incorreta! </p>
        <p><a href="login1.html" title="Layouts to make your own...">&lt; Retornar</a>
        </p>
</div>
</body></html>";

        exit;
    }
}
// Login inv�lido
else
{
    echo "
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>Servidor Administrativo</title><style type="text/css" media="all">@import "style.css";</style></head>

<body>

<div id="Header"></div>

<div id="Content">
        <h1>Autentica��o Inv�lida</h1>
        <p> O login fornecido n�o existe! </p>
        <p><a href="login1.html" title="Layouts to make your own...">&lt; Retornar</a>
        </p>
</div>
</body></html>";

    exit;
}
?> 
